from flask import  request, jsonify
from ..models import db ,User 
from datetime import datetime

def register():
    data = request.get_json()
    
    # Validate required fields
    required_fields = ['username', 'password', 'full_name']
    for field in required_fields:
        if not data.get(field):
            return jsonify({'message': f'{field} is required'}), 400
    
    # Check if user already exists
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'message': 'Username already exists'}), 409
    
    # Create new user
    user = User(
        username=data['username'],
        full_name=data['full_name'],
        qualification=data.get('qualification'),
        
        dob=datetime.strptime(data['dob'], '%Y-%m-%d').date() if data.get('dob') else None
    )
    user.set_password(data['password'])
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify({'message': 'User registered successfully'}), 201