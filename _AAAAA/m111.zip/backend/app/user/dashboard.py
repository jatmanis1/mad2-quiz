from flask import  jsonify
from ..models import db, User, Reservation
from ..authdghdr import get_current_user
def user_dashboard():
    try:
        current_user = get_current_user()
        
        # Get user's reservation statistics
        total_reservations = Reservation.query.filter_by(user_id=current_user.id).count()
        active_reservations = Reservation.query.filter_by(
            user_id=current_user.id, 
            is_active=True,
            leaving_timestamp=None
        ).count()
        
        # Recent reservations
        recent_reservations = Reservation.query.filter_by(
            user_id=current_user.id
        ).order_by(Reservation.created_at.desc()).limit(5).all()
        
        # Total amount spent
        completed_reservations = Reservation.query.filter(
            Reservation.user_id == current_user.id,
            Reservation.leaving_timestamp.isnot(None)
        ).all()
        total_spent = sum(res.parking_cost for res in completed_reservations)
        
        dashboard_data = {
            'user': current_user.to_dict(),
            'statistics': {
                'total_reservations': total_reservations,
                'active_reservations': active_reservations,
                'total_spent': round(total_spent, 2)
            },
            'recent_reservations': [res.to_dict() for res in recent_reservations]
        }
        
        return jsonify(dashboard_data), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500